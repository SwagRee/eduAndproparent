package com.zpl.common.config;

import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.ExceptionUtil;
import com.zpl.common.utils.RespBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常拦截
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    // 运行时异常拦截
    @ExceptionHandler(RuntimeException.class)
    public RespBean handlerRuntimeException(Exception e) {
        log.error(ExceptionUtil.getMessage(e));
        return RespBean.error().message("运行时异常：" + e.getMessage());
    }

    // 自定义异常拦截
    @ExceptionHandler(AuthException.class)
    public RespBean handlerAuthException(Exception e){
        log.error(ExceptionUtil.getMessage(e));
        return RespBean.error().message("自定义异常：" + e.getMessage());
    }

}
