package com.zpl.common.utils;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.HashMap;
import java.util.Map;

// 统一返回的结果（接口规范）
@Data
// 链式编程
@Accessors(chain = true)
@ApiModel("接口规范")
public class RespBean {
    @ApiModelProperty("状态码")
    private Integer code;
    @ApiModelProperty("提示信息")
    private String message;
    @ApiModelProperty("返回的数据")
    private Map<String, Object> data = new HashMap<String, Object>();

    public static RespBean success() {
        return new RespBean().setCode(200).setMessage("成功");
    }

    public static RespBean error() {
        return new RespBean().setCode(201).setMessage("失败");
    }

    public RespBean code(Integer code) {
        this.setCode(code);
        return this;
    }

    public RespBean message(String message) {
        this.setMessage(message);
        return this;
    }

    public RespBean data(String key, Object value) {
        this.data.put(key,value);
        return this;
    }

    public RespBean data(Map<String, Object> map) {
        this.setData(map);
        return this;
    }
}
