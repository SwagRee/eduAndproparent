package com.zpl.common.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class SpringWebMvcConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") //匹配所有路径
            .allowCredentials(true)  // 允许凭证
            .allowedHeaders("*") // 请求头
            .allowedMethods("GET","POST","PUT","DELETE") // 请求方法
            .allowedOriginPatterns("*");
    }

//    静态资源地址过滤
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        //访问服务器/images/edu/**的图片最终指向到文件真实路径
        registry.addResourceHandler("/images/edu/**")
                .addResourceLocations("file:E:\\edu-parent3\\images\\edu\\");
    }
}
