package com.zpl.common.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CorsConfig {
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        // 设置访问源地址
        corsConfiguration.addAllowedOrigin("*");
        // 设置访问请求头
        corsConfiguration.addAllowedHeader("*");
        // 设置访问请求方法
        corsConfiguration.addAllowedMethod("*");
        // 对接口跨域设置
        source.registerCorsConfiguration("/**",corsConfiguration);

        return new CorsFilter(source);
    }
}
