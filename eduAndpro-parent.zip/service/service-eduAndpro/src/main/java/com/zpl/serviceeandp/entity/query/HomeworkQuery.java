package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel("分页查询")
public class HomeworkQuery {
    private String homeworkId;

    private String homeworkName;

    private String studentId;

    private String score;

    private String description;

    private String evaluation;
    @ApiModelProperty(required = false)
    private Date createdTime;
    @ApiModelProperty(required = false)
    private Date endTime;
    @ApiModelProperty(required = false)
    private Date submitTime;
}
