package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Project;
import com.zpl.serviceeandp.entity.query.ProjectQuery;
import com.zpl.serviceeandp.service.ProjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@RestController
@RequestMapping("/serviceeandp/project")
@Api(tags = "实训项目模块")

public class ProjectController {
    @Autowired
    private ProjectService projectService;

    @ApiOperation("项目添加")
    @PostMapping("/add")
    public RespBean addProject(@RequestBody Project project) {
        project.setProjectId(UUID.randomUUID().toString());
        projectService.save(project);
        return RespBean.success();
    }

    @ApiOperation("项目删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") String id) {
        projectService.removeById(id);
        return RespBean.success();
    }

    @GetMapping("/get-list")
    @ApiOperation("获取项目列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<Project> list = projectService.list(null);
        Integer i1 = 0;

        Integer i2 = 0;

        Integer i3 = 0;
        LinkedHashMap<String, Integer> hashMap = new LinkedHashMap<>();

        for (Project project : list) {
            if (project.getProgress().equals("未完成")) {
                i1++;
            }
            if (project.getProgress().equals("进行中")) {
                i2++;
            }
            if (project.getProgress().equals("已完成")) {
                i3++;
            }
        }
        hashMap.put("未开始",i1);

        hashMap.put("进行中",i2);

        hashMap.put("已完成",i3);

        // 返回数据给客户端
        return RespBean.success().data("projectlist", hashMap);
    }
    @GetMapping("/get-list1")
    @ApiOperation("获取项目列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findList() {

        // 调用讲师业务层查询方法
        List<Project> list = projectService.list(null);

        // 返回数据给客户端
        return RespBean.success().data("projectlist", list);
    }
    @ApiOperation("查询对应id的学生")
    @GetMapping("/get-project-by-ids/{projectList}")
    public RespBean getStudentsByIds(@PathVariable List<String> projectList) {
        final Collection<Project> projects = projectService.listByIds(projectList);
        return RespBean.success().data("projectList", projects);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "projectQuery", value = "查询条件", required = true)
            ProjectQuery projectQuery
    ) {
        // 创建分页对象
        Page<Project> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        projectService.pageQuery(pageParams, projectQuery);
        // 获取分页查询的数据记录
        List<Project> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total", total).data("rows", records);
    }


    @ApiOperation(value = "修改课程信息")
    @PutMapping(value = {"change"})
    public RespBean changeInfo(@ApiParam(name = "projectInfo", value = "课程信息", required = true) @RequestBody Project project) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Project project1 = projectService.getById(project.getProjectId());
        if (project1 == null) {
            throw new AuthException("项目信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = projectService.updateById(project);
        if (!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

