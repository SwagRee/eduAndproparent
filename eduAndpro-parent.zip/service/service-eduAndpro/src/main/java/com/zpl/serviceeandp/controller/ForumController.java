package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Forum;
import com.zpl.serviceeandp.entity.query.ForumQuery;
import com.zpl.serviceeandp.service.ForumService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-02
 */
@RestController
@RequestMapping("/serviceeandp/forum")
public class ForumController {
    @Autowired
    private ForumService forumService;

    @ApiOperation("作业添加")
    @PostMapping(value={"add"})
    public RespBean addForum(@RequestBody Forum forum) {
        forum.setDate(new Date());


        forumService.save(forum);
        return RespBean.success();
    }

    @ApiOperation("作业删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") Integer id){
        forumService.removeById(id);
        return RespBean.success();
    }

    @ApiOperation("查询讲师信息")
    @GetMapping("/get-info/{id}")
    public RespBean getInfo(@PathVariable("id") Integer id) {
        Forum forum = forumService.getById(id);
        return RespBean.success().data("item",forum);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "forumQuery", value = "查询条件", required = true)
            ForumQuery forumQuery
    ) {
        // 创建分页对象
        Page<Forum> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        forumService.pageQuery(pageParams,forumQuery);
        // 获取分页查询的数据记录
        List<Forum> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @ApiOperation(value="修改用户信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="forumInfo", value="作业信息", required=true) @RequestBody Forum forum) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Forum forum1 = forumService.getById(forum.getId());
        if(forum1 == null) {
            throw new AuthException("讲师信息不存在");
        }
        // 调用讲师的修改方法

        boolean result = forumService.updateById(forum);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

