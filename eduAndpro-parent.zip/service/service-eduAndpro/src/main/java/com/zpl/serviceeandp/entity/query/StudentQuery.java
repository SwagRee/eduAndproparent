package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Data
@ApiModel("分页查询")
public class StudentQuery implements Serializable {

    private String name;

    private Integer age;

    private Integer sex;

    private String phone;

    private String school;

    private String companyId;

    private String projectId;

    private String positionId;

    private String teacherId;

    private String mainDirection;



}
