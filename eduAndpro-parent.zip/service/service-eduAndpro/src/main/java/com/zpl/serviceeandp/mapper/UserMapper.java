package com.zpl.serviceeandp.mapper;

import com.zpl.serviceeandp.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author demo
 * @since 2023-12-11
 */
public interface UserMapper extends BaseMapper<User> {

}
