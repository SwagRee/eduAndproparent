package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Course;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.CourseQuery;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2023-12-22
 */
public interface CourseService extends IService<Course> {

    void pageQuery(Page<Course> pageParams, CourseQuery courseQuery);
}
