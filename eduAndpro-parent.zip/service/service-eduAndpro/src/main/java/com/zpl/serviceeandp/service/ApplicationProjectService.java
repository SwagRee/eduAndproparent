package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.ApplicationProject;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.ApplicationProjectQuery;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2024-01-03
 */
public interface ApplicationProjectService extends IService<ApplicationProject> {

    void pageQuery(Page<ApplicationProject> pageParams, ApplicationProjectQuery applicationProjectQuery);
}
