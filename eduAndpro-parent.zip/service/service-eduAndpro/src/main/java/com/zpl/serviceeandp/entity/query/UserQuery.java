package com.zpl.serviceeandp.entity.query;


import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("分页查询")
public class UserQuery {

    private String username;

    private Integer permission;

}
