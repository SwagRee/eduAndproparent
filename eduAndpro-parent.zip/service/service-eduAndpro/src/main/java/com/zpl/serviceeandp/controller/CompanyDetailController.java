package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.CompanyDetail;
import com.zpl.serviceeandp.entity.User;
import com.zpl.serviceeandp.entity.query.CompanyQuery;
import com.zpl.serviceeandp.service.CompanyDetailService;
import com.zpl.serviceeandp.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@RestController
@RequestMapping("/serviceeandp/company-detail")
@Api(tags="公司详情模块")
public class CompanyDetailController {
    @Autowired
    private CompanyDetailService companyDetailService;

    @Autowired
    private UserService userService;

    @ApiOperation("公司添加")
    @PostMapping("/add")
    public RespBean addCompany(@RequestBody CompanyDetail companyDetail) {
        UUID uuid = UUID.randomUUID();
        final String uuidString = uuid.toString();

        companyDetail.setCompanyId(uuidString);
        final String uuidString2 = uuid.toString();

        final User user = new User();
        user.setUsername(companyDetail.getCompanyName());
        user.setPermission(2);
        user.setPassword(user.getUsername()+"123456");
        user.setAvatar(companyDetail.getAvatar());
        user.setUserId(uuidString2);
        userService.reg(user);

        companyDetail.setUserId(uuidString2);
        companyDetailService.save(companyDetail);
        return RespBean.success();
    }

    @ApiOperation("公司删除")
    @DeleteMapping("/del/{id}")
    public RespBean delCompany(@PathVariable("id") String id){
//        userService.removeById(companyDetailService.getById(id).getUserId());
        final CompanyDetail byId = companyDetailService.getById(id);
        userService.removeById(byId.getUserId());
        companyDetailService.removeById(id);
        return RespBean.success();
    }

    @GetMapping("/get-list")
    @ApiOperation("获取公司列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<CompanyDetail> list = companyDetailService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("companylist", list);
    }
    @ApiOperation("查询公司信息")
    @GetMapping("/get-info/{id}")
    public RespBean getInfo(@PathVariable("id") String id) {
        CompanyDetail companyDetail = companyDetailService.getById(id);
        return RespBean.success().data("item",companyDetail);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "teacherQuery", value = "查询条件", required = true)
            CompanyQuery teacherQuery
    ) {
        // 创建分页对象
        Page<CompanyDetail> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        companyDetailService.pageQuery(pageParams,teacherQuery);
        // 获取分页查询的数据记录
        List<CompanyDetail> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @DeleteMapping("/del-more")
    @ApiOperation("批量删除")
    public RespBean delMore(String[] ids) {
        boolean result = companyDetailService.removeByIds(Arrays.asList(ids));
        if(!result) {
            throw new AuthException("批量删除失败");
        }
        return RespBean.success();
    }

    @ApiOperation(value="修改学生信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="companyInfo", value="学生信息", required=true) @RequestBody CompanyDetail companyDetail) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        CompanyDetail companyDetail11 = companyDetailService.getById(companyDetail.getUserId());
        if(companyDetail11 == null) {
            throw new AuthException("公司信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = companyDetailService.updateById(companyDetail);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

