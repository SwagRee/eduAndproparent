package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.serviceeandp.entity.User;
import com.zpl.serviceeandp.entity.query.UserQuery;
import com.zpl.serviceeandp.mapper.UserMapper;
import com.zpl.serviceeandp.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.util.Date;
import java.util.UUID;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-11
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Override
    public void reg(User user) {
//        1、判断用户名是否重复，重复则抛出异常提示
        QueryWrapper queryWrapper = new QueryWrapper<User>();
        queryWrapper.eq("username", user.getUsername());
        User result = baseMapper.selectOne(queryWrapper);


        if (result != null) {
            throw new AuthException("用户名重复，请换个名称试试");
        }
//        2、注册用户（密码加密）
//        设计密码加密，(盐值salt + 密码password +盐值salt)MD5
        String salt = UUID.randomUUID().toString().toUpperCase();
        String password = user.getPassword();
        String md5Password = md5Pwd(salt, password);
//        保存盐值及加密密码
        user.setSalt(salt);
        user.setPassword(md5Password);

        user.setCreateTime(new Date());
        user.setUpdateTime(new Date());
        user.setLoginTime(new Date());

        int rows = baseMapper.insert(user);
        if (rows != 1) {
            throw new AuthException("注册用户失败");
        }
    }

    @Override
    public void login(User user) {
        QueryWrapper queryWrapper = new QueryWrapper<User>();
        queryWrapper.eq("username", user.getUsername());
        User result = baseMapper.selectOne(queryWrapper);

        if (result == null) {
            throw new AuthException("用户名不存在，请换个名称试试或去注册");
        }
//       2.检验密码
        String password = user.getPassword();
        String salt = result.getSalt();
        String oldPwd = result.getPassword();
        String newMd5Pwd = md5Pwd(salt, password);
        if (!newMd5Pwd.equals(oldPwd)) {
            throw new AuthException("密码输入错误，请重新输入");
        }
        user.setLoginTime(new Date());

    }


    @Override
    public void pageQuery(Page<User> page, UserQuery userQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("user_id");
        // 无查询条件，则只调用分页方法
        if (userQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        final String username = userQuery.getUsername();
        final Integer permission = userQuery.getPermission();
        // 判断非空

        if (!StringUtils.isEmpty(username)) {
            queryWrapper.like("username", username);
        }
        if (permission != null) {
            queryWrapper.eq("permission", permission);
        }

        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);

    }

    /**
     * 使用md5加密
     *
     * @param salt
     * @param password
     * @return
     */
    public static String md5Pwd(String salt, String password) {
        for (int i = 0; i < 3; i++) {
            password = DigestUtils.md5DigestAsHex((salt + password + salt).getBytes()).toUpperCase();
        }
        return password;
    }

    @Override
    public User getUserByName(String username) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username);
        return baseMapper.selectOne(queryWrapper);
    }


}
