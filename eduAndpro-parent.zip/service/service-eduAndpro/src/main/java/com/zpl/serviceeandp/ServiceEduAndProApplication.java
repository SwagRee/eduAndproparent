package com.zpl.serviceeandp;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@MapperScan("com.zjgs.serviceeandp.mapper")
@ComponentScan("com.zjgs")
public class ServiceEduAndProApplication {
    public static void main(String[] args) {SpringApplication.run(ServiceEduAndProApplication.class,args);}
}
