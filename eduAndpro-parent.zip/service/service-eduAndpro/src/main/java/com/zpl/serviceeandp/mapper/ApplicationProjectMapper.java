package com.zpl.serviceeandp.mapper;

import com.zpl.serviceeandp.entity.ApplicationProject;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author demo
 * @since 2024-01-03
 */
public interface ApplicationProjectMapper extends BaseMapper<ApplicationProject> {

}
