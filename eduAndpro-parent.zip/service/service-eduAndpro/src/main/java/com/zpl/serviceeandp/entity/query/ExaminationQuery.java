package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel("分页查询")
public class ExaminationQuery {
    private String examinationId;

    private String examinationName;

    private String description;

    private String score;

    private String studentId;

    private Date createdTime;
    @ApiModelProperty(required = false)
    private Date endTine;
    @ApiModelProperty(required = false)
    private Date submitTime;
}
