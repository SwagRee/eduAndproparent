package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Course;
import com.zpl.serviceeandp.entity.query.CourseQuery;
import com.zpl.serviceeandp.mapper.CourseMapper;
import com.zpl.serviceeandp.service.CourseService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-22
 */
@Service
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course> implements CourseService {

    @Override
    public void pageQuery(Page<Course> page, CourseQuery courseQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<Course> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("course_id");
        // 无查询条件，则只调用分页方法
        if(courseQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        final String courseName = courseQuery.getCourseName();
        final String creator = courseQuery.getCreator();
        final Integer category = courseQuery.getCategory();
        // 判断非空
        if(!StringUtils.isEmpty(courseName)){
            queryWrapper.like("course_name",courseName);
        }
        if(creator != null) {
            queryWrapper.like("creator",creator);
        }
//        if(category!=0) {
//            queryWrapper.eq("category",category);
//        }
        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);
    }
}
