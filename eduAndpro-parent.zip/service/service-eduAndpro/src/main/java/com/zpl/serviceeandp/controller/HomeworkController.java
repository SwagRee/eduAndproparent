package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Homework;
import com.zpl.serviceeandp.entity.query.HomeworkQuery;
import com.zpl.serviceeandp.service.HomeworkService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@RestController
@RequestMapping("/serviceeandp/homework")
@Api(tags="日常作业模块")

public class HomeworkController {
    @Autowired
    private HomeworkService homeworkService;

    @ApiOperation("作业添加")
    @PostMapping(value={"add"})
    public RespBean addHomework(@RequestBody Homework homework) {
        homework.setHomeworkId(UUID.randomUUID().toString());
        homework.setCreatedTime(new Date());
        homework.setEndTime(new Date());
        homework.setSubmitTime(new Date());

        homeworkService.save(homework);
        return RespBean.success();
    }

    @ApiOperation("作业删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") String id){
        homeworkService.removeById(id);
        return RespBean.success();
    }

    @ApiOperation("查询讲师信息")
    @GetMapping("/get-info/{id}")
    public RespBean getInfo(@PathVariable("id") String id) {
        Homework homework = homeworkService.getById(id);
        return RespBean.success().data("item",homework);
    }
    @ApiOperation("查询讲师信息")
    @GetMapping("/get-info1/{studentId}")
    public RespBean getInfoByStudentId(@PathVariable("studentId") String studentId) {
        final List<String> scoresByStudentId = homeworkService.getScoresByStudentId(studentId);
        int sum = 0;
        for(String s:scoresByStudentId){
            Integer integer = Integer.valueOf(s);
            sum = sum + integer;
        }
        final int i = sum / scoresByStudentId.size();

        final HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put(studentId,i);
        return RespBean.success().data("item",hashMap);
    }

    @ApiOperation("查询讲师信息")
    @GetMapping("/get-info2/{studentId}")
    public RespBean getScoreByStudentId(@PathVariable("studentId") String studentId) {
        final List<String> scoresByStudentId = homeworkService.getScoresByStudentId(studentId);
        Integer i1=0;
        Integer i2=0;
        Integer i3=0;
        Integer i4=0;
        Integer i5=0;

        for(String s:scoresByStudentId){
            final Integer integer = Integer.valueOf(s);
            if(integer>=90){
                i1++;
            }
            if(integer>=80&&integer<90){
                i2++;
            }
            if(integer>=70&&integer<80){
                i3++;
            }
            if(integer>=60&&integer<70){
                i4++;
            }
            if(integer<60){
                i5++;
            }
        }
        final LinkedHashMap<String, Integer> stringIntegerLinkedHashMap = new LinkedHashMap<>();
        stringIntegerLinkedHashMap.put("90-100",i1);
        stringIntegerLinkedHashMap.put("80-90",i2);
        stringIntegerLinkedHashMap.put("70-80",i3);
        stringIntegerLinkedHashMap.put("60-70",i4);
        stringIntegerLinkedHashMap.put("不及格",i5);

        return RespBean.success().data("item",stringIntegerLinkedHashMap);
    }
    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "homeworkQuery", value = "查询条件", required = true)
            HomeworkQuery homeworkQuery
    ) {
        // 创建分页对象
        Page<Homework> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        homeworkService.pageQuery(pageParams,homeworkQuery);
        // 获取分页查询的数据记录
        List<Homework> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @ApiOperation(value="修改用户信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="homeworkInfo", value="作业信息", required=true) @RequestBody Homework homework) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Homework homework1 = homeworkService.getById(homework.getHomeworkId());
        if(homework1 == null) {
            throw new AuthException("讲师信息不存在");
        }
        // 调用讲师的修改方法
        homework.setCreatedTime(new Date());
        homework.setEndTime(new Date());
        homework.setSubmitTime(new Date());
        boolean result = homeworkService.updateById(homework);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

