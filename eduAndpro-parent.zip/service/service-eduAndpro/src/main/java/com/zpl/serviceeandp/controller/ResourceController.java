package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Resource;
import com.zpl.serviceeandp.entity.query.ResourceQuery;
import com.zpl.serviceeandp.service.ResourceService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-01
 */
@RestController
@RequestMapping("/serviceeandp/resource")
public class ResourceController {
    @Autowired
    private ResourceService resourceService;

    @ApiOperation("资源添加")
    @PostMapping("/add")
    public RespBean addProject(@RequestBody Resource resource) {
        resourceService.save(resource);
        return RespBean.success();
    }

    @ApiOperation("资源删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") Integer id){
        resourceService.removeById(id);
        return RespBean.success();
    }



    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "projectQuery", value = "查询条件", required = true)
            ResourceQuery resourceQuery
    ) {
        // 创建分页对象
        Page<Resource> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        resourceService.pageQuery(pageParams,resourceQuery);
        // 获取分页查询的数据记录
        List<Resource> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }
    @GetMapping("/get-list")
    @ApiOperation("获取岗位列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<Resource> list = resourceService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("resourcelist", list);
    }

    @ApiOperation(value="修改课程信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="projectInfo", value="课程信息", required=true) @RequestBody Resource resource ){
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Resource resource1 = resourceService.getById(resource.getId());
        if(resource1 == null) {
            throw new AuthException("项目信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = resourceService.updateById(resource);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

