package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.Date;


@Data
@ApiModel("分页查询")
public class VideoQuery {
    private String videoName;

    private String title;

    private String description;

    private Date createdTime;

    private Date updateName;

    private String videoAddress;

}
