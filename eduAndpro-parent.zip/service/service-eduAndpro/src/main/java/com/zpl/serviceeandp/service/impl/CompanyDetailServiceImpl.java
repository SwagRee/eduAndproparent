package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.CompanyDetail;
import com.zpl.serviceeandp.entity.query.CompanyQuery;
import com.zpl.serviceeandp.mapper.CompanyDetailMapper;
import com.zpl.serviceeandp.service.CompanyDetailService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Service
public class CompanyDetailServiceImpl extends ServiceImpl<CompanyDetailMapper, CompanyDetail> implements CompanyDetailService {

    @Override
    public void pageQuery(Page<CompanyDetail> page, CompanyQuery companyQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<CompanyDetail> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("company_id");
        // 无查询条件，则只调用分页方法
        if(companyQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        String companyName = companyQuery.getCompanyName();
        Integer companyAddress = companyQuery.getCompanyAddress();
        String companyPeopleNum = companyQuery.getCompanyPeopleNum();
        String phone = companyQuery.getPhone();
        // 判断非空
        if(!StringUtils.isEmpty(companyName)){
            queryWrapper.like("company_name",companyName);
        }
        if(companyAddress != null) {
            queryWrapper.eq("company_address",companyAddress);
        }
        if(!StringUtils.isEmpty(companyPeopleNum)) {
            queryWrapper.ge("company_people_num",companyPeopleNum);
        }
        if(!StringUtils.isEmpty(phone)) {
            queryWrapper.le("phone",phone);
        }
        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);

    }

    @Override
    public String changeInfo(CompanyDetail companyDetail) {
        return null;
    }
}
