package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.ApplicationProject;
import com.zpl.serviceeandp.entity.Student;
import com.zpl.serviceeandp.entity.query.ApplicationProjectQuery;
import com.zpl.serviceeandp.service.ApplicationProjectService;
import com.zpl.serviceeandp.service.StudentService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-03
 */
@RestController
@RequestMapping("/serviceeandp/application-project")
public class ApplicationProjectController {
    @Autowired
    private ApplicationProjectService applicationProjectService;
    @Autowired
    private StudentService studentService;

    @ApiOperation("项目申请添加")
    @PostMapping("/add")
    public RespBean addCompany(@RequestBody ApplicationProject applicationProject) {
        applicationProjectService.save(applicationProject);
        return RespBean.success();
    }

    @ApiOperation("项目申请删除")
    @DeleteMapping("/del/{id}")
    public RespBean delCompany(@PathVariable("id") Integer id){
        applicationProjectService.removeById(id);
        return RespBean.success();
    }

    @GetMapping("/get-list")
    @ApiOperation("获取项目申请列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<ApplicationProject> list = applicationProjectService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("applicationprojectlist", list);
    }
    @ApiOperation("查询项目申请信息")
    @GetMapping("/get-info/{id}")
    public RespBean getInfo(@PathVariable("id") Integer id) {
        ApplicationProject applicationProject = applicationProjectService.getById(id);
        return RespBean.success().data("item",applicationProject);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "teacherQuery", value = "查询条件", required = true)
            ApplicationProjectQuery applicationProjectQuery
    ) {
        // 创建分页对象
        Page<ApplicationProject> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        applicationProjectService.pageQuery(pageParams,applicationProjectQuery);
        // 获取分页查询的数据记录
        List<ApplicationProject> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @DeleteMapping("/del-more")
    @ApiOperation("批量删除")
    public RespBean delMore(String[] ids) {
        boolean result = applicationProjectService.removeByIds(Arrays.asList(ids));
        if(!result) {
            throw new AuthException("批量删除失败");
        }
        return RespBean.success();
    }

    @ApiOperation(value="修改项目申请信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="applicationprojectInfo", value="项目申请信息", required=true) @RequestBody ApplicationProject applicationProject) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        ApplicationProject applicationProject11 = applicationProjectService.getById(applicationProject.getUserId());
        if(applicationProject11 == null) {
            throw new AuthException("项目申请信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = applicationProjectService.updateById(applicationProject);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }

    @ApiOperation(value="通过项目申请信息")
    @PutMapping("/pass")
    public RespBean toPass(@ApiParam(name="xiugai", value="xiugai", required=true) @RequestBody ApplicationProject applicationProject) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        applicationProject.setProgress(1);

        boolean result = applicationProjectService.updateById(applicationProject);
        if(!result) {
            throw new AuthException("修改失败");
        }

        final String userId = applicationProject.getUserId();
        Student student = studentService.getById(userId);
        student.setProjectId(applicationProject.getProjectId());

        studentService.updateById(student);

        return RespBean.success();
    }

    @ApiOperation(value="取消项目申请信息")
    @PutMapping("/deny")
    public RespBean toDeny(@ApiParam(name="deny", value="deny", required=true) @RequestBody ApplicationProject applicationProject) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        applicationProject.setProgress(0);

        boolean result = applicationProjectService.updateById(applicationProject);
        if(!result) {
            throw new AuthException("修改失败");
        }
        final String userId = applicationProject.getUserId();
        Student student = studentService.getById(userId);
        student.setProjectId("");

        studentService.updateById(student);

        return RespBean.success();
    }
}

