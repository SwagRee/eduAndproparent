package com.zpl.serviceeandp.mapper;

import com.zpl.serviceeandp.entity.ApplicationPratice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author demo
 * @since 2024-01-03
 */
public interface ApplicationPraticeMapper extends BaseMapper<ApplicationPratice> {

}
