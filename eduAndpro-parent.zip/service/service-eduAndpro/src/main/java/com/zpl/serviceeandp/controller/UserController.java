package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.query.UserQuery;
import com.zpl.serviceeandp.service.CompanyDetailService;
import com.zpl.serviceeandp.service.StudentService;
import com.zpl.serviceeandp.service.TeacherService;
import com.zpl.serviceeandp.service.UserService;
import com.zpl.serviceeandp.entity.CompanyDetail;
import com.zpl.serviceeandp.entity.Student;
import com.zpl.serviceeandp.entity.Teacher;
import com.zpl.serviceeandp.entity.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-11
 */
@RestController
@RequestMapping("/serviceeandp/user")
@Api(tags="用户模块")

public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private TeacherService teacherService;

    @Autowired
    private CompanyDetailService companyDetailService;

    @ApiOperation(value="注册用户")
    @PostMapping(value={"reg"})
    public RespBean reg(@RequestBody User user) {
        UUID uuid = UUID.randomUUID();
        final String uuidString = uuid.toString();
        user.setUserId(uuidString);
        this.userService.reg(user);
        if(user.getPermission() == 0){
            Student student = new Student();
            student.setAvatar(user.getAvatar());
            student.setName(user.getUsername());
            addStudentVoid(student,uuidString);
        }
        if(user.getPermission() == 1){
            Teacher teacher = new Teacher();
            teacher.setAvatar(user.getAvatar());
            teacher.setTeacherName(user.getUsername());
            addTeacherVoid(teacher,uuidString);
        }
        if(user.getPermission() == 2){
            CompanyDetail companyDetail = new CompanyDetail();
            companyDetail.setAvatar(user.getAvatar());
            companyDetail.setCompanyName(user.getUsername());
            addCompanyVoid(companyDetail,uuidString);
        }
        return RespBean.success();
    }

    public RespBean addStudentVoid(Student student,String userUUIDString) {
        UUID uuid = UUID.randomUUID();
        final String uuidString = uuid.toString();
        student.setStudentId(uuidString);


        student.setUserId(userUUIDString);

        studentService.save(student);
        return RespBean.success();
    }

    public RespBean addTeacherVoid(Teacher teacher,String userUUIDString) {
        UUID uuid = UUID.randomUUID();
        final String uuidString = uuid.toString();
        teacher.setTeacherId(uuidString);
        teacher.setUserId(userUUIDString);

        teacherService.save(teacher);
        return RespBean.success();
    }

    public RespBean addCompanyVoid(CompanyDetail companyDetail,String userUUIDString) {
        UUID uuid = UUID.randomUUID();
        final String uuidString = uuid.toString();
        companyDetail.setCompanyId(uuidString);
        companyDetail.setUserId(userUUIDString);
        companyDetailService.save(companyDetail);
        return RespBean.success();
    }
    @ApiOperation("查询信息")
    @GetMapping("/get-info/{username}")
    public RespBean getInfo(@PathVariable("username") String username) {
        final User userByName = userService.getUserByName(username);

        return RespBean.success().data("item",userByName);
    }

    @ApiOperation(value="登录用户")
    @PostMapping(value={"login"})
    public RespBean login(@RequestBody User user) {
        this.userService.login(user);
        return RespBean.success();
    }

    @GetMapping("/get-list")
    @ApiOperation("获取用户列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<User> list = userService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("userlist", list);
    }

    @ApiOperation("用户删除")
    @DeleteMapping("/del/{id}")
    public RespBean delArticle(@PathVariable("id") String id){
        final Integer permission = userService.getById(id).getPermission();
        userService.removeById(id);
        if(permission == 0){
            studentService.removeById(id);
        }
        if(permission == 1){
            teacherService.removeById(id);
        }
        if(permission == 2){
            companyDetailService.removeById(id);
        }
        return RespBean.success();
    }


    @ApiOperation(value="修改用户信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="userInfo", value="用户信息", required=true) @RequestBody User user) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        User user1 = userService.getById(user.getUserId());
        if(user1 == null) {
            throw new AuthException("讲师信息不存在");
        }
        String salt = UUID.randomUUID().toString().toUpperCase();
        String password = user.getPassword();
        String md5Password = md5Pwd(salt, password);
//        保存盐值及加密密码
        user.setSalt(salt);
        user.setPassword(md5Password);
        // 调用讲师的修改方法
        boolean result = userService.updateById(user);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "teacherQuery", value = "查询条件", required = true)
            UserQuery userQuery
    ) {
        // 创建分页对象
        Page<User> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        userService.pageQuery(pageParams,userQuery);
        // 获取分页查询的数据记录
        List<User> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    // 图片类型的常量
    public static final List<String> AVATAR_TYPE = new ArrayList<String>();
    static {
        AVATAR_TYPE.add("image/jpeg");
        AVATAR_TYPE.add("image/png");
        AVATAR_TYPE.add("image/gif");
        AVATAR_TYPE.add("image/webp");
    }

    //    获取上传图像的磁盘地址
    @Value("${file.path}")
    private String uploadPath;

    @PostMapping("/upload-avatar")
    @ApiOperation("上传讲师图像")
    public RespBean uploadAvatar(MultipartFile file) {
        if(file.isEmpty()){
            throw new AuthException("上传文件不能为空");
        }

        if(!AVATAR_TYPE.contains(file.getContentType())){
            throw new AuthException("文件类型不符合，请上传图片类型");
        }

//        保存图片至磁盘
//        1、获取保存图片的地址
        File dir = new File(uploadPath);
        if(!dir.exists()){ // 不存在目录则创建
            dir.mkdirs();
        }
//        2、图片名随机生成 1.jpg => djakdjakdaldak.jpg
        String randomFileName = UUID.randomUUID().toString();
//        3、取出图片类型（后缀名）
        String fileName = file.getOriginalFilename(); // 获取整个文件名
//        3.2 根据.符号取出索引
        int index = fileName.lastIndexOf(".");
//        3.3 根据索引截取.符号后的字符串
        String suffix = fileName.substring(index);
//        4 拼接完整的文件名
        String overName = randomFileName + suffix;

//        5. 保存图片至磁盘
        File dest = new File(dir, overName);

        try {
            file.transferTo(dest);
        }catch (IOException e) {
            throw new AuthException("保存图片失败");
        }

//        6、将图片地址保存至数据库
        String avatar = "/images/edu/" + overName;

//        7、返回地址给客户端
        return RespBean.success().data("uploadUrl",avatar);
    }
    private String md5Pwd(String salt, String password) {
        for (int i = 0; i < 3; i++) {
            password = DigestUtils.md5DigestAsHex((salt + password + salt).getBytes()).toUpperCase();
        }
        return password;
    }

    @ApiOperation("查询对应id的用户")
    @GetMapping("/get-user-by-ids/{userList}")
    public RespBean getStudentsByIds(@PathVariable List<String> userList) {
        final Collection<User> users = userService.listByIds(userList);
        return RespBean.success().data("userList", users);
    }
}

