package com.zpl.serviceeandp.entity.query;

import lombok.Data;

@Data
public class StudyRoomQuery {

    private String title;

    private String address;
}
