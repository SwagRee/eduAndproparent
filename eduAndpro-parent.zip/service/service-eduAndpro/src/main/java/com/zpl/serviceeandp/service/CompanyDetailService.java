package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.CompanyDetail;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.CompanyQuery;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
public interface CompanyDetailService extends IService<CompanyDetail> {

    void pageQuery(Page<CompanyDetail> pageParams, CompanyQuery teacherQuery);

    String changeInfo(CompanyDetail companyDetail);
}
