package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Student;
import com.zpl.serviceeandp.entity.query.StudentQuery;
import com.zpl.serviceeandp.mapper.StudentMapper;
import com.zpl.serviceeandp.service.StudentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Service
public class StudentServiceImpl extends ServiceImpl<StudentMapper, Student> implements StudentService {

    @Override
    public void pageQuery(Page<Student> page, StudentQuery studentQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<Student> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("student_id");
        // 无查询条件，则只调用分页方法
        if(studentQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        String name = studentQuery.getName();
        final Integer age = studentQuery.getAge();
        final String phone = studentQuery.getPhone();
        final String school = studentQuery.getSchool();
        final Integer sex = studentQuery.getSex();
        final String mainDirection = studentQuery.getMainDirection();
        // 判断非空

        if(!StringUtils.isEmpty(name)){
            queryWrapper.like("name",name);
        }
        if(age != null) {
            queryWrapper.eq("age",age);
        }

        if(!StringUtils.isEmpty(phone)) {
            queryWrapper.le("phone",phone);
        }
        if(!StringUtils.isEmpty(school)) {
            queryWrapper.le("school",school);
        }
        if(sex != null) {
            queryWrapper.le("sex",sex);
        }
        if(!StringUtils.isEmpty(mainDirection)) {
            queryWrapper.le("mainDirection",mainDirection);
        }
        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);

    }

    @Override
    public List<Student> getStudentById(String teacherId) {
            QueryWrapper<Student> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("teacher_id", teacherId);
            return baseMapper.selectList(queryWrapper);

    }
}
