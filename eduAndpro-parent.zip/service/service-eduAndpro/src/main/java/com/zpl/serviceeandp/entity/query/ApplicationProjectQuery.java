package com.zpl.serviceeandp.entity.query;


import lombok.Data;

@Data
public class ApplicationProjectQuery {

    private String userId;

    private String projectId;

    private String message;

}
