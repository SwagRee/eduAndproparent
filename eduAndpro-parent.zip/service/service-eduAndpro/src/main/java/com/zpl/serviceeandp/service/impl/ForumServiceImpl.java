package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Forum;
import com.zpl.serviceeandp.entity.query.ForumQuery;
import com.zpl.serviceeandp.mapper.ForumMapper;
import com.zpl.serviceeandp.service.ForumService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author demo
 * @since 2024-01-02
 */
@Service
public class ForumServiceImpl extends ServiceImpl<ForumMapper, Forum> implements ForumService {

    @Override
    public void pageQuery(Page<Forum> page, ForumQuery forumQuery) {

        // 创建查询wrapper对象e
        QueryWrapper<Forum> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("id");
        // 无查询条件，则只调用分页方法
        if (forumQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        final String message = forumQuery.getMessage();

        if (!StringUtils.isEmpty(message)) {
            queryWrapper.like("message", message);
        }

        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);

    }
}
