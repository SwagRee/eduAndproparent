package com.zpl.serviceeandp.mapper;

import com.zpl.serviceeandp.entity.CompanyPosition;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
public interface CompanyPositionMapper extends BaseMapper<CompanyPosition> {

}
