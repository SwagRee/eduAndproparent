package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Task;
import com.zpl.serviceeandp.entity.query.TaskQuery;
import com.zpl.serviceeandp.service.TaskService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Api(tags="任务模块")
@RestController
@RequestMapping("/serviceeandp/task")
public class TaskController {
    @Autowired
    private TaskService taskService;

    @ApiOperation("添加任务")
    @PostMapping("/add")
    public RespBean addTask(Task task) {
        taskService.save(task);
        return RespBean.success();
    }

    @ApiOperation("删除任务")
    @DeleteMapping("/del/{id}")
    public RespBean delTask(@PathVariable("id") String id){
        taskService.removeById(id);
        return RespBean.success();
    }

    @GetMapping("/get-list")
    @ApiOperation("获取公司列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<Task> list = taskService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("tasklist", list);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "teacherQuery", value = "查询条件", required = true)
            TaskQuery taskQuery
    ) {
        // 创建分页对象
        Page<Task> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        taskService.pageQuery(pageParams,taskQuery);
        // 获取分页查询的数据记录
        List<Task> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }
}

