package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Studyroom;
import com.zpl.serviceeandp.entity.query.StudyRoomQuery;
import com.zpl.serviceeandp.service.StudyroomService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-02
 */
@RestController
@RequestMapping("/serviceeandp/studyroom")
public class StudyroomController {
    @Autowired
    private StudyroomService studyroomService;

    @ApiOperation("岗位添加")
    @PostMapping("/add")
    public RespBean addPosition(@RequestBody Studyroom studyroom) {
        studyroomService.save(studyroom);
        return RespBean.success();
    }

    @ApiOperation("岗位删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") Integer id){
        studyroomService.removeById(id);
        return RespBean.success();
    }

    @GetMapping("/get-list")
    @ApiOperation("获取孵化空间列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<Studyroom> list = studyroomService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("studylist", list);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "teacherQuery", value = "查询条件", required = true)
            StudyRoomQuery studyRoomQuery
    ) {
        // 创建分页对象
        Page<Studyroom> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        studyroomService.pageQuery(pageParams,studyRoomQuery);
        // 获取分页查询的数据记录
        List<Studyroom> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @ApiOperation(value="修改岗位信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="positionInfo", value="岗位信息", required=true) @RequestBody Studyroom studyroom) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Studyroom studyroom1 = studyroomService.getById(studyroom.getId());
        if(studyroom1 == null) {
            throw new AuthException("公司信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = studyroomService.updateById(studyroom);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

