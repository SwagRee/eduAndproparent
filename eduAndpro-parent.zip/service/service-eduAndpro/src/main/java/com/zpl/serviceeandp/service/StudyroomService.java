package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Studyroom;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.StudyRoomQuery;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2024-01-02
 */
public interface StudyroomService extends IService<Studyroom> {

    void pageQuery(Page<Studyroom> pageParams, StudyRoomQuery studyRoomQuery);
}
