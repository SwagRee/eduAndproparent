package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.UserQuery;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2023-12-11
 */
public interface UserService extends IService<User> {
    void reg(User user);

    void login(User user);

    void pageQuery(Page<User> pageParams, UserQuery userQuery);

    User getUserByName(String name);
}
