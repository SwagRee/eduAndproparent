package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Pratice;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.PraticeQuery;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
public interface PraticeService extends IService<Pratice> {

    void pageQuery(Page<Pratice> pageParams, PraticeQuery praticeQuery);
}
