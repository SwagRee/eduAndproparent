package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Teacher;
import com.zpl.serviceeandp.entity.query.TeacherQuery;
import com.zpl.serviceeandp.service.TeacherService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@RestController
@RequestMapping("/serviceeandp/teacher")
@Api(tags="教师信息")

public class TeacherController {
    @Autowired
    private TeacherService teacherService;

    @ApiOperation("教师添加")
    @PostMapping(value={"add"})
    public RespBean addStudent(@RequestBody  Teacher teacher) {
        teacher.setTeacherId(UUID.randomUUID().toString());
        teacherService.save(teacher);
        return RespBean.success();
    }

    @ApiOperation("教师删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") String id){
        teacherService.removeById(id);
        return RespBean.success();
    }

    @ApiOperation("查询讲师信息")
    @GetMapping("/get-info/{id}")
    public RespBean getInfo(@PathVariable("id") String id) {
        Teacher teacher = teacherService.getById(id);
        return RespBean.success().data("item",teacher);
    }
    @GetMapping("/get-list")
    @ApiOperation("获取公司列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<Teacher> list = teacherService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("teacherlist", list);
    }
    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "teacherQuery", value = "查询条件", required = true)
            TeacherQuery teacherQuery
    ) {
        // 创建分页对象
        Page<Teacher> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        teacherService.pageQuery(pageParams,teacherQuery);
        // 获取分页查询的数据记录
        List<Teacher> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @ApiOperation(value="修改用户信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="teacherInfo", value="教师信息", required=true) @RequestBody Teacher teacher) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Teacher teacher1 = teacherService.getById(teacher.getUserId());
        if(teacher1 == null) {
            throw new AuthException("讲师信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = teacherService.updateById(teacher);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

