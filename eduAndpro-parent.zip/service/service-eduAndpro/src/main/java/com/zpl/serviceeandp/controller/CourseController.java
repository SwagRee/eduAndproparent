package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Course;
import com.zpl.serviceeandp.entity.query.CourseQuery;
import com.zpl.serviceeandp.service.CourseService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-22
 */
@RestController
@RequestMapping("/serviceeandp/course")
public class CourseController {
    @Autowired
    private CourseService courseService;

    @ApiOperation("课程添加")
    @PostMapping(value={"add"})
    public RespBean addCourse(@RequestBody Course course) {
        course.setCreateTime(new Date().toString());
        courseService.save(course);
        return RespBean.success();
    }

    @ApiOperation("课程删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") Integer id){
        courseService.removeById(id);
        return RespBean.success();
    }

    @ApiOperation("查询讲师信息")
    @GetMapping("/get-info/{id}")
    public RespBean getInfo(@PathVariable("id") String id) {
        Course course = courseService.getById(id);
        return RespBean.success().data("item",course);
    }

    @GetMapping("/get-list")
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<Course> list = courseService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("courselist", list);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "courseQuery", value = "查询条件", required = true)
            CourseQuery courseQuery
    ) {
        // 创建分页对象
        Page<Course> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        courseService.pageQuery(pageParams,courseQuery);
        // 获取分页查询的数据记录
        List<Course> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @ApiOperation(value="修改课程信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="courseInfo", value="课程信息", required=true) @RequestBody Course course) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Course course1 = courseService.getById(course.getCourseId());
        if(course1 == null) {
            throw new AuthException("课程信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = courseService.updateById(course);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }

}

