package com.zpl.serviceeandp.mapper;

import com.zpl.serviceeandp.entity.Course;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author demo
 * @since 2023-12-22
 */
public interface CourseMapper extends BaseMapper<Course> {

}
