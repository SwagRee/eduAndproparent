package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.ApplicationPratice;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.ApplicationPraticeQuery;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2024-01-03
 */
public interface ApplicationPraticeService extends IService<ApplicationPratice> {

    void pageQuery(Page<ApplicationPratice> pageParams, ApplicationPraticeQuery applicationProjectQuery);
}
