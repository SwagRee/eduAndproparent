package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Homework;
import com.zpl.serviceeandp.entity.query.HomeworkQuery;
import com.zpl.serviceeandp.mapper.HomeworkMapper;
import com.zpl.serviceeandp.service.HomeworkService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Service
public class HomeworkServiceImpl extends ServiceImpl<HomeworkMapper, Homework> implements HomeworkService {

    @Override
    public void pageQuery(Page<Homework> page, HomeworkQuery homeworkQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<Homework> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("homework_id");
        // 无查询条件，则只调用分页方法
        if (homeworkQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        final String homeworkName = homeworkQuery.getHomeworkName();

        if (!StringUtils.isEmpty(homeworkName)) {
            queryWrapper.like("homework_name", homeworkName);
        }

        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);
    }

    @Override
    public List<String> getScoresByStudentId(String studentId) {
        QueryWrapper<Homework> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("student_id", studentId);
        final List<Homework> homeworks = baseMapper.selectList(queryWrapper);
        final ArrayList<String> scores = new ArrayList<>();
        for (Homework homework1 : homeworks) {
            final String score = homework1.getScore();
            scores.add(score);
        }
        return scores;
    }
}
