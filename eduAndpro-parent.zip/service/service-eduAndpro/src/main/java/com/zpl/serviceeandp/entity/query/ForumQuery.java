package com.zpl.serviceeandp.entity.query;

import lombok.Data;

import java.util.Date;

@Data
public class ForumQuery {
    private Date date;

    private String message;
}
