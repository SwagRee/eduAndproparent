package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Student;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.StudentQuery;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
public interface StudentService extends IService<Student> {

    void pageQuery(Page<Student> pageParams, StudentQuery studentQuery);

    List<Student> getStudentById(String teacherId);
}
