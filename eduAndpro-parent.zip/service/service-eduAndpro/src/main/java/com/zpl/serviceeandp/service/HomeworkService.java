package com.zpl.serviceeandp.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Homework;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zpl.serviceeandp.entity.query.HomeworkQuery;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
public interface HomeworkService extends IService<Homework> {

    void pageQuery(Page<Homework> pageParams, HomeworkQuery homeworkQuery);

    List<String> getScoresByStudentId(String name);

}
