package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("分页查询")
public class CompanyQuery {
    @ApiModelProperty("公司名称")
    private String companyName;
    @ApiModelProperty("公司地址")
    private Integer companyAddress;
    @ApiModelProperty("公司人数")
    private String companyPeopleNum;
    @ApiModelProperty("公司联系方式")
    private String phone;
}
