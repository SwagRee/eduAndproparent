package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("分页查询")
public class CourseQuery {

    private String courseName;

    private String description;

    private String creator;

    private String createTime;

    private String cover;

    private Integer category;
}
