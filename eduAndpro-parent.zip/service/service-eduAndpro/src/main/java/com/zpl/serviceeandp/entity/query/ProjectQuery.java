package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("分页查询")
public class ProjectQuery {
    @ApiModelProperty("项目名称")
    private String projectName;
    @ApiModelProperty("项目进度")
    private Integer progress;
    @ApiModelProperty("项目简述")
    private String projectDescription;
}
