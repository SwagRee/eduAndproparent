package com.zpl.serviceeandp.entity.query;

import lombok.Data;

@Data
public class ApplicationPraticeQuery {
    private String message;
}
