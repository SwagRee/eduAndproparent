package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Video;
import com.zpl.serviceeandp.entity.query.VideoQuery;
import com.zpl.serviceeandp.mapper.VideoMapper;
import com.zpl.serviceeandp.service.VideoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Service
public class VideoServiceImpl extends ServiceImpl<VideoMapper, Video> implements VideoService {
    @Autowired
    public VideoMapper videoMapper;

    @Override
    public void pageQuery(Page<Video> page, VideoQuery videoQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<Video> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("video_id");
        // 无查询条件，则只调用分页方法
        if (videoQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        String videoName = videoQuery.getVideoName();
        // 判断非空

        if (!StringUtils.isEmpty(videoName)) {
            queryWrapper.like("video_name", videoName);
        }

        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);

    }

    @Override
    public List<Video> getVideosByCourseId(String courseId) {
        QueryWrapper<Video> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("course_id", courseId);
        return videoMapper.selectList(queryWrapper);
    }

}

