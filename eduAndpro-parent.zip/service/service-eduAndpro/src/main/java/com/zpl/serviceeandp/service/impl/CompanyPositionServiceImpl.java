package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.CompanyPosition;
import com.zpl.serviceeandp.entity.query.CompanyPositionQuery;
import com.zpl.serviceeandp.mapper.CompanyPositionMapper;
import com.zpl.serviceeandp.service.CompanyPositionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Service
public class CompanyPositionServiceImpl extends ServiceImpl<CompanyPositionMapper, CompanyPosition> implements CompanyPositionService {

    @Override
    public void pageQuery(Page<CompanyPosition> page, CompanyPositionQuery companyPositionQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<CompanyPosition> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("position_id");
        // 无查询条件，则只调用分页方法
        if(companyPositionQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        final String positionName = companyPositionQuery.getPositionName();
        final Integer description = companyPositionQuery.getDescription();
        // 判断非空
        if(!StringUtils.isEmpty(positionName)){
            queryWrapper.like("position_name",positionName);
        }
        if(description != null) {
            queryWrapper.eq("description",description);
        }
        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);
    }
}
