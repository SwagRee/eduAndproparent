package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("分页查询")
public class CompanyPositionQuery {
    @ApiModelProperty("岗位名称")
    private String positionName;
    @ApiModelProperty("岗位描述")
    private Integer description;
}
