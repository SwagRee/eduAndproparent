package com.zpl.serviceeandp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.serviceeandp.entity.Teacher;
import com.zpl.serviceeandp.entity.query.TeacherQuery;
import com.zpl.serviceeandp.mapper.TeacherMapper;
import com.zpl.serviceeandp.service.TeacherService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@Service
public class TeacherServiceImpl extends ServiceImpl<TeacherMapper, Teacher> implements TeacherService {


    @Override
    public void pageQuery(Page<Teacher> page, TeacherQuery teacherQuery) {
        // 创建查询wrapper对象e
        QueryWrapper<Teacher> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("teacher_id");
        // 无查询条件，则只调用分页方法
        if(teacherQuery == null) {
            baseMapper.selectPage(page, queryWrapper);
            return;
        }

        // 取出查询的多条件
        String teacherName = teacherQuery.getTeacherName();
        String teacherPosition = teacherQuery.getTeacherPosition();
        String phone = teacherQuery.getTeacherPhone();
        // 判断非空

        if(!StringUtils.isEmpty(teacherName)){
            queryWrapper.like("teacher_name",teacherName);
        }
        if(teacherPosition != null) {
            queryWrapper.eq("teacher_positiopn",teacherPosition);
        }

        if(!StringUtils.isEmpty(phone)) {
            queryWrapper.le("teacher_phone",phone);
        }
        // 调用查询方法
        baseMapper.selectPage(page, queryWrapper);

    }
}
