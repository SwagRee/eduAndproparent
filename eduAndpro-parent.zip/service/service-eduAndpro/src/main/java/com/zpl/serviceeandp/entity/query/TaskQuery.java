package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel("分页查询")

public class TaskQuery {
    @ApiModelProperty("任务名称")

    private String taskName;

    @ApiModelProperty("任务描述")

    private String description;


    @ApiModelProperty("任务进程")

    private String taskProgress;

}
