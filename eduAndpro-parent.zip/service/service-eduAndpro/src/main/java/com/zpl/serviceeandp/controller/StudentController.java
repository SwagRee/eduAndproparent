package com.zpl.serviceeandp.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zpl.common.exception.AuthException;
import com.zpl.common.utils.RespBean;
import com.zpl.serviceeandp.entity.Student;
import com.zpl.serviceeandp.entity.query.StudentQuery;
import com.zpl.serviceeandp.service.StudentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2023-12-12
 */
@RestController
@RequestMapping("/serviceeandp/student")
@Api(tags="学生信息模块")

public class StudentController {
    @Autowired
    private StudentService studentService;

    @ApiOperation("学生添加")
    @PostMapping("/add")
    public RespBean addStudent(@RequestBody Student student) {
        UUID uuid = UUID.randomUUID();
        final String uuidString = uuid.toString();
        student.setStudentId(uuidString);

        UUID uuid2 = UUID.randomUUID();
        final String uuidString2 = uuid2.toString();
        student.setUserId(uuidString2);

        studentService.save(student);
        return RespBean.success();
    }



    @ApiOperation("学生删除")
    @DeleteMapping("/del/{id}")
    public RespBean delPosition(@PathVariable("id") String id){
        studentService.removeById(id);
        return RespBean.success();
    }

    @GetMapping("/get-list")
    @ApiOperation("获取学生列表")
//    @CrossOrigin  // 局部访问通过跨域（只能针对当前方法）
    public RespBean findAllList() {

        // 调用讲师业务层查询方法
        List<Student> list = studentService.list(null);
        // 返回数据给客户端
        return RespBean.success().data("studentlist", list);
    }

    @ApiOperation("查询对应id的学生")
    @GetMapping("/get-student-by-id/{userId}")
    public RespBean getStudentByStudentId(@PathVariable String userId) {
        Student student = studentService.getById(userId);
        return RespBean.success().data("student", student);
    }
    @ApiOperation("查询对应id的学生")
    @GetMapping("/get-student-by-ids/{userIdList}")
    public RespBean getStudentsByIds(@PathVariable List<String> userIdList) {
        final Collection<Student> students = studentService.listByIds(userIdList);
        return RespBean.success().data("studentList", students);
    }

    @ApiOperation("查询有对应教师学生")
    @GetMapping("/get-student-by-teacher-id/{teacherId}")
    public RespBean getVideosByCourseId(@PathVariable String teacherId) {
        List<Student> studentList = studentService.getStudentById(teacherId);
        return RespBean.success().data("studentlist", studentList);
    }

    // 多条件+分页查询
    @GetMapping("/get_page/{page}/{limit}")
    @ApiOperation("多条件+分页查询")
    public RespBean getPageList(
            @ApiParam(name = "page", value = "当前页码", required = true)
            @PathVariable("page") Integer page,
            @ApiParam(name = "limit", value = "每页记录数", required = true)
            @PathVariable("limit") Integer limit,
            @ApiParam(name = "studentQuery", value = "查询条件", required = true)
            StudentQuery studentQuery
    ) {
        // 创建分页对象
        Page<Student> pageParams = new Page<>(page, limit);
        // 调用业务层分页查询方法
        studentService.pageQuery(pageParams,studentQuery);
        // 获取分页查询的数据记录
        List<Student> records = pageParams.getRecords();

        long total = pageParams.getTotal();
        // 返回分页查询的记录给前端
        return RespBean.success().data("total",total).data("rows",records);
    }

    @ApiOperation(value="修改学生信息")
    @PutMapping(value={"change"})
    public RespBean changeInfo(@ApiParam(name="studentInfo", value="学生信息", required=true) @RequestBody Student student) {
        // 调用查询id的方法，判断讲师是否存在，存在则修改
        Student teacher1 = studentService.getById(student.getUserId());
        if(teacher1 == null) {
            throw new AuthException("学生信息不存在");
        }
        // 调用讲师的修改方法
        boolean result = studentService.updateById(student);
        if(!result) {
            throw new AuthException("修改失败");
        }

        return RespBean.success();
    }
}

