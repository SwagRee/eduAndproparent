package com.zpl.serviceeandp.entity.query;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("分页查询")
public class TeacherQuery {
    @ApiModelProperty("教师名称")

    private String teacherName;

    @ApiModelProperty("教师职务")

    private String teacherPosition;

    @ApiModelProperty("教师联系方式")

    private String teacherPhone;

    @ApiModelProperty("教师简介")

    private String description;
}
