package com.zpl.serviceeandp.entity.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("分页查询")
public class PraticeQuery {
    @ApiModelProperty("实训名称")
    private String praticeName;
    @ApiModelProperty("联系方式")
    private String phone;
    @ApiModelProperty("实训简述")
    private String description;
}
