package com.zpl.servicevod.controller;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.vod.model.v20170321.GetVideoPlayAuthRequest;
import com.aliyuncs.vod.model.v20170321.GetVideoPlayAuthResponse;
import com.zpl.common.utils.RespBean;
import com.zpl.servicevod.service.VideoService;
import com.zpl.servicevod.utils.AliyunVodSDK;
import com.zpl.servicevod.utils.ConstantProperties;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/vod/video")
@Api(tags = "视频点播模块")
public class VideoController {

    @Autowired
    private VideoService videoService;

    @ApiOperation("上传视频")
    @PostMapping("upload")
    public RespBean upload(
            @ApiParam(name = "file", value = "视频文件", required = true)
                    MultipartFile file
    ){
        String videoId = videoService.uploadVideo(file);

        return RespBean.success().data("videoId", videoId);
    }

    @ApiOperation("获取视频播放凭证")
    @GetMapping("get-play-auth/{videoId}")
    public RespBean getPlayAuth(@PathVariable("videoId") String videoId) throws ClientException {
        String keyId = ConstantProperties.KEY_ID;
        String keySecret = ConstantProperties.KEY_SECRET;
        // 超级试驾
        DefaultAcsClient client = AliyunVodSDK.initVodClient(keyId, keySecret);

        GetVideoPlayAuthRequest request = new GetVideoPlayAuthRequest();

        request.setVideoId(videoId);

        GetVideoPlayAuthResponse acsResponse = client.getAcsResponse(request);

        String playAuth = acsResponse.getPlayAuth();

        //返回凭证给前端
        return RespBean.success().data("playAuth",playAuth);
    }

}

