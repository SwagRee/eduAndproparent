package com.zpl.servicevod.utils;

public class ConstantProperties {

    public static final String KEY_ID = "LTAI5tJLWsK4cUsPGwAHuJCP";
    public static final String KEY_SECRET = "ADnANcpFuKtfM70Pq3hwJSvASLunUz";
}
