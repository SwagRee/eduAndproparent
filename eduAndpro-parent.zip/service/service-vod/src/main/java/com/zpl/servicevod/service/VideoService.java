package com.zpl.servicevod.service;

import org.springframework.web.multipart.MultipartFile;

/**
 * 上传视频
 */
public interface VideoService {
    String uploadVideo(MultipartFile file);
}
