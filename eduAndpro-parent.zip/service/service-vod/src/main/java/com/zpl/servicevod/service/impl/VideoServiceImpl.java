package com.zpl.servicevod.service.impl;

import com.aliyun.vod.upload.impl.UploadVideoImpl;
import com.aliyun.vod.upload.req.UploadStreamRequest;
import com.aliyun.vod.upload.resp.UploadStreamResponse;
import com.zpl.servicevod.service.VideoService;
import com.zpl.servicevod.utils.ConstantProperties;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

@Service
public class VideoServiceImpl implements VideoService {

    @Override
    public String uploadVideo(MultipartFile file) {
        try {
            String accessKeyId = ConstantProperties.KEY_ID;
            String accessKeySecret = ConstantProperties.KEY_SECRET;
            String title = file.getOriginalFilename();
            InputStream inputStream = file.getInputStream();

            // 创建上传请求
            UploadStreamRequest request = new UploadStreamRequest(accessKeyId, accessKeySecret, title, title, inputStream);



            // 执行上传请求
            UploadVideoImpl uploader = new UploadVideoImpl();
            UploadStreamResponse response = uploader.uploadStream(request);

            // 获取上传成功后的视频ID
            String videoId = response.getVideoId();

            return videoId;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
