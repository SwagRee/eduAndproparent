package com.swagree.lab.bean;

import lombok.Data;

@Data
public class Text {

    private String role;

    private String content;

}
