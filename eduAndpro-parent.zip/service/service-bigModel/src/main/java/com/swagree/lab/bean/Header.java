package com.swagree.lab.bean;

import lombok.Data;


@Data
public class Header {

    private int code;

    private int status;

    private String sid;

}
