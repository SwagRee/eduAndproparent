package com.swagree.lab.bean;

import lombok.Data;

@Data
public class Payload {

    private Choices choices;

}
