package com.swagree.lab.service;

import com.swagree.lab.bean.ResultBean;

public interface PushService {

    void pushToOne(String uid, String text);

    void pushToAll(String text);

    ResultBean pushMessageToXFServer(String uid, String text);
}
