package com.swagree.lab.bean;

import lombok.Data;

import java.util.List;


@Data
public class Choices {

    private List<Text> text;

}
