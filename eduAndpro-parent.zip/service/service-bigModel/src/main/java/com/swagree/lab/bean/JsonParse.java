package com.swagree.lab.bean;

import lombok.Data;


@Data
public class JsonParse {

    private Header header;

    private Payload payload;

}
