package com.zpl.serviceoss.service.impl;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.CannedAccessControlList;
import com.zpl.common.exception.AuthException;
import com.zpl.serviceoss.service.FileService;
import com.zpl.serviceoss.utils.ConstantProperties;
import org.joda.time.DateTime;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

@Service
public class FileServiceImpl implements FileService {

    @Override
    public String upload(MultipartFile file) {

        // 获取阿里云相关常量
        String endpoint = ConstantProperties.END_POINT;
        String keyId = ConstantProperties.KEY_ID;
        String keySecret = ConstantProperties.KEY_SECRET;
        String bucketName = ConstantProperties.BUCKET_NAME;

//        文件路径地址
        String uploadUrl = null;

        try {

//        创建文件上传流
            OSSClient ossClient = new OSSClient(endpoint, keyId, keySecret);
//        bucketName如果不存在则用代码的方式创建
            if(!ossClient.doesBucketExist(bucketName)){
//            创建bucket
                ossClient.createBucket(bucketName);
//            设置bucket权限
                ossClient.setBucketAcl(bucketName, CannedAccessControlList.PublicRead);

            }
            //        获取上传文件的流
            InputStream inputStream = file.getInputStream();

//            保存文件至阿里云OSS
            String datePath = new DateTime().toString("yyyy/MM/dd");

//            文件后缀名处理
            String fileName = file.getOriginalFilename();
            String randomName = UUID.randomUUID().toString();
            int index = fileName.lastIndexOf(".");
            String suffix = fileName.substring(index);
            String overName = randomName + suffix;

//            完整路径拼接
            String fileUrl = datePath + "/" + overName;

//            调用阿里云文件保存文件方法
            ossClient.putObject(bucketName, fileUrl, inputStream);

//            关闭oss
            ossClient.shutdown();

//            返回完整的阿里云OSS地址
            uploadUrl = "https://" + bucketName + "." + endpoint + "/" + fileUrl;

        } catch (IOException e) {
            throw new AuthException("文件上传失败" + e.getMessage());
        }

        return uploadUrl;
    }

}
