package com.zpl.serviceoss.Controller;

import com.zpl.common.utils.RespBean;
import com.zpl.serviceoss.service.FileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/oss/file")
@Api(tags = "oss文件上传")
public class FileController {

    @Autowired
    private FileService fileService;

    @PostMapping("upload")
    @ApiOperation("上传文件")
    public RespBean upload(MultipartFile file) {
//        调用业务层接口方法
        String uploadUrl = fileService.upload(file);
//        返回结果给客户端
        return RespBean.success().data("url", uploadUrl);

    }

}
